package edu.wgu.d387_sample_code.rest;


import edu.wgu.d387_sample_code.translation.DisplayMessage;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.Locale;

@RestController
@RequestMapping("/welcome")
public class WelcomeController {
    private DisplayMessage displayMessage = new DisplayMessage();

    @GetMapping("/en")
    public String getWelcomeMessageEn(){
        return displayMessage.getWelcomeMessage(Locale.US);
    }

    @GetMapping("/fr")
    public String getWelcomeMessageFr(){
        return displayMessage.getWelcomeMessage(Locale.CANADA_FRENCH);
    }
}
