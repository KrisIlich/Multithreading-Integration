package edu.wgu.d387_sample_code;
import java.util.Locale;

import edu.wgu.d387_sample_code.translation.DisplayMessage;
import edu.wgu.d387_sample_code.translation.DisplayMessage.java;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class D387SampleCodeApplication {

	public static void main(String[] args) {
		SpringApplication.run(D387SampleCodeApplication.class, args);
		DisplayMessage displayMessageEn = new DisplayMessage();
		DisplayMessage displayMessageFr = new DisplayMessage();

		Thread threadEn = new Thread(() -> {
			displayMessageEn.getWelcomeMessage(Locale.US);
		});

		Thread threadFr = new Thread(() -> {
			displayMessageFr.getWelcomeMessage(Locale.CANADA_FRENCH);
		});

		threadEn.start();
		threadFr.start();





	}

}
