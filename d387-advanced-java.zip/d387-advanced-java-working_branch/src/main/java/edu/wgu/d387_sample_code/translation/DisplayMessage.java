package edu.wgu.d387_sample_code.translation;
import java.util.Locale;
import java.util.ResourceBundle;


public class DisplayMessage {

    ResourceBundle bundle = ResourceBundle.getBundle("translation");


    public String getWelcomeMessage(Locale locale) {
        bundle = ResourceBundle.getBundle("translation", locale);
        return bundle.getString("welcomeMessage");
    }

    public static void main(String[] args) {
        DisplayMessage displayMessage = new DisplayMessage();

        String englishMessage = displayMessage.getWelcomeMessage(Locale.US);
        String frenchMessage = displayMessage.getWelcomeMessage(Locale.CANADA_FRENCH);

    }





}
