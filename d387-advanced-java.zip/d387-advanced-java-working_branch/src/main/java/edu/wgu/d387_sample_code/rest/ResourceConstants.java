package edu.wgu.d387_sample_code.rest;

public class ResourceConstants {
    public static final String ROOM_RESERVATION_V1 = "/room/reservation/v1";
}
